#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include "arraylist.h"

void read(char **);

int finish(char *);

void functions(ArrayList *, char *);

#endif
